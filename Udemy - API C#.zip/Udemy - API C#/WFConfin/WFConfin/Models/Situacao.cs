﻿namespace WFConfin.Models
{
    public enum Situacao
    {
        Aberta = 0, 
        Paga = 1
    }
}
